<?php
    session_start();
    require("redirects.php");
    logout();
?>